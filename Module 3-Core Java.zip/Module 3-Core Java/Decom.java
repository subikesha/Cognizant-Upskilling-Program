public class Demo {

    public static void main(String[] args) {
        System.out.println("CTS Exercise");
    }
}